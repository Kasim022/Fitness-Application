package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.widget.TextView;

/**
 * Activity class for displaying BMI category and description.
 */
public class BMICard extends AppCompatActivity {

    // Views
    private TextView BMICategoryTxt, BMIDescriptionTxt;
    private CardView BMICategoryLayout, BMIDescriptionLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmicard);

        // Initialize views
        BMICategoryLayout = findViewById(R.id.BMICategoryLayout);
        BMICategoryTxt = findViewById(R.id.BMICategoryTxt);
        BMIDescriptionTxt = findViewById(R.id.BMIDescriptionTxt);
        BMIDescriptionLayout = findViewById(R.id.BMIDescriptionLayout);

        // Get BMI result from intent
        double BMIResult = getIntent().getDoubleExtra("BMIResult", 0.0);

        // Set BMI category and description based on BMI result
        setBMICategoryTxt(BMIResult);
    }

    /**
     * Set BMI category text and description based on BMI result.
     * @param bmiResult The BMI result to determine the category and description.
     */
    private void setBMICategoryTxt(double bmiResult) {
        if (bmiResult < 18.5) {
            BMICategoryTxt.setText("Underweight");
            BMIDescriptionTxt.setText("It's important to focus on a balanced diet and seek guidance from healthcare professionals to achieve a healthy weight");
        } else if (bmiResult >= 18.5 && bmiResult < 25.0) {
            BMICategoryTxt.setText("Healthy Weight");
            BMIDescriptionTxt.setText("Congratulations! You are in the healthy weight range. Maintain a well-balanced diet and regular physical activity for optimal health.");
        } else if (bmiResult >= 25.0 && bmiResult < 30.0) {
            BMICategoryTxt.setText("Overweight");
            BMIDescriptionTxt.setText("You fall into the category of being overweight. Adopting a healthier lifestyle, which includes nutritious eating habits and increased physical activity, can help with weight loss. ");
        } else if (bmiResult >= 30.0 && bmiResult < 35.0) {
            BMICategoryTxt.setText("Obesity (Class 1)");
            BMIDescriptionTxt.setText("You are classified as obese (Class 1). This indicates a higher risk of health problems. Consider making lifestyle changes such as diet and exercise more often.");
        } else if (bmiResult >= 35.0 && bmiResult < 40.0) {
            BMICategoryTxt.setText("Obesity (Class 2)");
            BMIDescriptionTxt.setText("You are in the obesity (Class 2) category. This level of obesity increases the risk of health complications. It's important to seek guidance from healthcare professionals to manage your weight and overall health");
        } else {
            BMICategoryTxt.setText("Obesity (Class 3)");
            BMIDescriptionTxt.setText("You are in the obesity (Class 3) category. You are classified as obese (Class 3). Immediate intervention by healthcare professionals is required to address the related health hazards through comprehensive lifestyle changes.");
        }
    }
}
