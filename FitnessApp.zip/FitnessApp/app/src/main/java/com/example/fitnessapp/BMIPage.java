package com.example.fitnessapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.util.NumberUtils;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.Firebase;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DecimalFormat;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class BMIPage extends AppCompatActivity {

    EditText Weight, Height, AgeEditText;
    Button btnsubmit;

    Spinner spinnerGender;
    TextView result;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmipage);

        Weight = findViewById(R.id.WeightEditText);
        Height = findViewById(R.id.HeightEditText);
        AgeEditText = findViewById(R.id.AgeEditText);
        btnsubmit = findViewById(R.id.btnSubmit);
        spinnerGender = findViewById(R.id.spinnerGender);
        mAuth = FirebaseAuth.getInstance();
        FirebaseApp.initializeApp(this); //Initialize Firebase

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.options_list, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);

        //applies adapter to the spinner
        spinnerGender.setAdapter(adapter);


        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String WeightText = Weight.getText().toString();
                String HeightText = Height.getText().toString();
                String ageText = AgeEditText.getText().toString();

                String selectedGender = spinnerGender.getSelectedItem().toString();

                boolean fieldEmpty = false;

                if (TextUtils.isEmpty(WeightText)) {
                    Toast.makeText(BMIPage.this, "Please Enter Weight", Toast.LENGTH_SHORT).show();
                    fieldEmpty = true;
                }
                if (TextUtils.isEmpty(HeightText)) {
                    Toast.makeText(BMIPage.this, "Please Enter Height", Toast.LENGTH_SHORT).show();
                    fieldEmpty = true;
                }
                if (TextUtils.isEmpty(ageText)) {
                    Toast.makeText(BMIPage.this, "Please Enter Age", Toast.LENGTH_SHORT).show();
                }
                if (!fieldEmpty) {
                    //Calculating BMI
                    double weight = Double.parseDouble(WeightText);
                    double height = Double.parseDouble(HeightText) / 100;
                    double BMI = weight / (height * height);
                    DecimalFormat df = new DecimalFormat("#.#");
                    String formattedBMI = df.format(BMI);

                    Intent intent = new Intent(BMIPage.this, StepCounter.class);
                    intent.putExtra("BMIResult", formattedBMI);
                    startActivity(intent);

                    FirebaseUser currentUser = mAuth.getCurrentUser();
                if (currentUser != null) {
                    String userUid = currentUser.getUid();
                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    CollectionReference bmiResultCollection = db.collection("users"); // Create a reference to the collection
                    DocumentReference userDocument = bmiResultCollection.document(userUid); // Create a document with the user's email as the document ID

                    Map<String, Object> bmiData = new HashMap<>();
                    bmiData.put("weight", WeightText);
                    bmiData.put("Height", HeightText);
                    bmiData.put("Age", ageText);
                    bmiData.put("bmi", formattedBMI);


                    // Add a subcollection "bmi" and store the data in it
                    userDocument.collection("bmi").add(bmiData)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    Log.d("BMIPage", "BMI data successfully stored in Firestore");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w("BMIPage", "Error storing BMI data in Firestore", e);
                                }
                            });
                }

            }
             }
         });

     }
}