package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.widget.TextView;


public class CaloriesBurnedCard extends AppCompatActivity {

    private TextView CaloriesBurnTxt, CaloriesBurnDescriptionTxt;
    private CardView CaloriesBurnDescriptionLayout, CaloriesBurnedLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calories_burned_card);

        CaloriesBurnedLayout = findViewById(R.id.CaloriesBurnedLayout);
        CaloriesBurnTxt = findViewById(R.id.CaloriesBurnedTxt);
        CaloriesBurnDescriptionLayout = findViewById(R.id.CaloriesBurnDescriptionLayout);
        CaloriesBurnDescriptionTxt = findViewById(R.id.CaloriesBurnDescriptionTxt);

    }

}