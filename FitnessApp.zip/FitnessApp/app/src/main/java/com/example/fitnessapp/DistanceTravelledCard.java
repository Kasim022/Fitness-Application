package com.example.fitnessapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DistanceTravelledCard extends AppCompatActivity implements OnMapReadyCallback {

    private MapView mapView;
    private GoogleMap GMap;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private List<LatLng> polylinePoints = new ArrayList<>();
    private Polyline polyline;

    private static final long UPDATE_INTERVAL = 5000;
    private static final long FASTEST_INTERVAL = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distance_travelled_card);

        mapView = findViewById(R.id.MapView);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);

        // Initialize the FusedLocationProviderClient
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Load previously saved polyline data
        polylinePoints = loadPolylineData();

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        GMap = googleMap;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true);

            locationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    super.onLocationResult(locationResult);
                    onLocationChanged(locationResult.getLastLocation());
                }
            };
            polyline = googleMap.addPolyline(new PolylineOptions().color(Color.BLUE).width(5));
            startLocationUpdates();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mapView.getMapAsync(this);
            } else {
                Toast.makeText(this, "Permission denied. App cannot function properly.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startLocationUpdates() {
        LocationRequest locationRequest = new LocationRequest();
        locationRequest.setInterval(UPDATE_INTERVAL);
        locationRequest.setFastestInterval(FASTEST_INTERVAL);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);

    }

    private void onLocationChanged(Location location) {
        if (location != null) {
            LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
            polylinePoints.add(latLng);
            polyline.setPoints(polylinePoints);
        }
    }

    private void savePolylineData(List<LatLng> polylinePoints) {
        SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Clear any existing polyline data
        editor.remove("polyline_data");

        // Convert LatLng objects to a set of strings
        Set<String> polylineDataSet = new HashSet<>();
        for (LatLng point : polylinePoints) {
            polylineDataSet.add(point.latitude + "," + point.longitude);
        }

        // Store the set of polyline data strings
        editor.putStringSet("polyline_data", polylineDataSet);
        editor.apply();
    }

    private List<LatLng> loadPolylineData() {
        List<LatLng> polylinePoints = new ArrayList<>();
        SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
        Set<String> polylineDataSet = sharedPreferences.getStringSet("polyline_data", null);

        if (polylineDataSet != null) {
            // Convert the set of strings back to LatLng objects
            for (String pointStr : polylineDataSet) {
                String[] coords = pointStr.split(",");
                double lat = Double.parseDouble(coords[0]);
                double lng = Double.parseDouble(coords[1]);
                polylinePoints.add(new LatLng(lat, lng));
            }
        }
        return polylinePoints;
    }


    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        savePolylineData(polylinePoints);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
