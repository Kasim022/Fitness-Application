package com.example.fitnessapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.FirebaseApp;

/**
 * Activity class for handling user login.
 */
public class MainActivity extends AppCompatActivity {

    // Views
    TextInputEditText EmailEditText, PasswordEditText;
    TextInputLayout EmailTextInputLayout, PasswordTextInputLayout;
    Button btnSubmit;
    TextView SignUpHere;
    // Firebase Authentication instance
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firebase Authentication
        mAuth = FirebaseAuth.getInstance();
        FirebaseApp.initializeApp(this);

        // Initialize views
        EmailTextInputLayout = findViewById(R.id.EmailTextInputLayout);
        PasswordTextInputLayout = findViewById(R.id.PasswordTextInputLayout);
        EmailEditText = findViewById(R.id.EmailEditText);
        PasswordEditText = findViewById(R.id.PasswordEditText);
        btnSubmit = findViewById(R.id.btnSubmit);
        SignUpHere = findViewById(R.id.SignUpHere);

        // Button click listener for login
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Email, Password;

                Email = String.valueOf(EmailEditText.getText().toString());
                Password = String.valueOf(PasswordEditText.getText().toString());
                boolean FieldEmpty = false;

                // Check if email or password is empty
                if (TextUtils.isEmpty(Email)) {
                    Toast.makeText(MainActivity.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
                    FieldEmpty = true;
                }

                if (TextUtils.isEmpty(Password)) {
                    Toast.makeText(MainActivity.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                    FieldEmpty = true;
                }

                // If fields are not empty, proceed with login
                if (!FieldEmpty) {
                    mAuth.signInWithEmailAndPassword(Email, Password).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Intent intent = new Intent(MainActivity.this, BMIPage.class);
                                startActivity(intent);
                                Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                            } else {
                                String errorMessage = task.getException().getMessage();
                                Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }
            }
        });

        // Click listener for sign-up text
        SignUpHere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, RegisterPage.class);
                startActivity(intent);
                SignUpHere.requestFocus();
            }
        });
    }
}
