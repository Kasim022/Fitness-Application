package com.example.fitnessapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import java.lang.reflect.Field;

public class RegisterPage extends AppCompatActivity {

    TextInputEditText FirstNameEditText, LastNameEditText, EmailInput, PasswordInput, ConfirmPasswordInput;
    Button btnRegister;
    TextView LoginHereTXT;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        mAuth = FirebaseAuth.getInstance(); // Initialize FirebaseAuth

        FirstNameEditText = findViewById(R.id.FirstNameEditText);
        LastNameEditText = findViewById(R.id.LastNameEditText);
        EmailInput = findViewById(R.id.EmailInput);
        PasswordInput = findViewById(R.id.ConfirmPasswordInput);
        ConfirmPasswordInput = findViewById(R.id.ConfirmPasswordInput);
        btnRegister = findViewById(R.id.btnRegister);
        LoginHereTXT = findViewById(R.id.LoginHereTXT);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String FirstName, Lastname, Email, Password, ConfirmPassword;
                FirstName = String.valueOf(FirstNameEditText.getText()).trim();
                Lastname = String.valueOf(LastNameEditText.getText()).trim();
                Email = String.valueOf(EmailInput.getText()).trim();
                Password = String.valueOf(PasswordInput.getText()).trim();
                ConfirmPassword = String.valueOf(ConfirmPasswordInput.getText()).trim();

                boolean FieldEmpty = false; //check if field is empty

                if (TextUtils.isEmpty(FirstName) || TextUtils.isEmpty(Lastname)) {
                    Toast.makeText(RegisterPage.this, "Please Enter Name", Toast.LENGTH_SHORT).show();
                    FieldEmpty = true;
                }
                if (TextUtils.isEmpty(Email)) {
                    Toast.makeText(RegisterPage.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
                }
                if (TextUtils.isEmpty(Password)) {
                    Toast.makeText(RegisterPage.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                }
                if (TextUtils.isEmpty(ConfirmPassword)) {
                    Toast.makeText(RegisterPage.this, "Please Enter Confirm Password", Toast.LENGTH_SHORT).show();
                }
                if (!FieldEmpty) {
                    mAuth.createUserWithEmailAndPassword(Email, Password).addOnCompleteListener(RegisterPage.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(RegisterPage.this, "Registration Successful", Toast.LENGTH_SHORT).show();

                                FirebaseFirestore FB = FirebaseFirestore.getInstance();
                                CollectionReference usersRef = FB.collection("users");

                                //Creating User Object with user data to store in database
                                users user = new users();
                                user.setFirstName(FirstName);
                                user.setLastName(Lastname);
                                user.setEmail(Email);
                                user.setPassword(Password);

                                usersRef.add(user).addOnSuccessListener(documentReference -> {
                                            String documentID = documentReference.getId();

                                            Intent intent = new Intent(RegisterPage.this, MainActivity.class);
                                            startActivity(intent);

                                        })
                                        .addOnFailureListener(e -> {
                                            Toast.makeText(RegisterPage.this, "Firestore Error" + e.getMessage(), Toast.LENGTH_SHORT).show();

                                        });

                            } else {
                                //If Registration Fails
                                String errorMessage = task.getException().getMessage();
                                Toast.makeText(RegisterPage.this, "Registration Failed: " + errorMessage, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });

        LoginHereTXT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterPage.this, MainActivity.class);
                startActivity(intent);
                overrideActivityTransition();
            }
        });
    }

    private void overrideActivityTransition() {

        View rootView = findViewById(android.R.id.content); // Get the root view of the activity

        ObjectAnimator slideIn = ObjectAnimator.ofFloat(findViewById(android.R.id.content), "translationX", 0f );
        slideIn.setDuration(400);
        slideIn.start();


    }
}