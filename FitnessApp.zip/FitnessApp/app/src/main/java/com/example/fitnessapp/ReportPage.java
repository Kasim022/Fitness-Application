package com.example.fitnessapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;

/**
 * Activity class for displaying the report page with step count.
 */
public class ReportPage extends AppCompatActivity {

    private BottomNavigationView nav;
    private BarChart barChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_page);

        // Initialize views
        barChart = findViewById(R.id.BarChart);
        nav = findViewById(R.id.nav);

        // Retrieve current step count from intent
        String currentStepString = getIntent().getStringExtra("currentStep");
        if (currentStepString != null) {
            float currentStep = Float.parseFloat(currentStepString);
            Log.d("ReportPage", "Total Step: " + currentStep);

            // Create BarEntry list with current step count
            ArrayList<BarEntry> entries = new ArrayList<>();
            entries.add(new BarEntry(1, currentStep));

            // Create BarDataSet with step count data
            BarDataSet dataSet = new BarDataSet(entries, "Steps");
            dataSet.setColor(Color.rgb(0, 0, 255)); // Set color for the bar

            // Create BarData with the dataset
            BarData data = new BarData(dataSet);
            dataSet.setBarBorderWidth(0.5f); // Set border width for bars

            // Set data to the bar chart and refresh it
            barChart.setData(data);
            barChart.invalidate();
        }

        // Bottom navigation item selection
        nav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemID = item.getItemId();
                if (itemID == R.id.nav_menu) {
                    Intent intent = new Intent(ReportPage.this, StepCounter.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                } else if (itemID == R.id.nav_Workout) {
                    Intent intent = new Intent(ReportPage.this, WorkoutPage.class);
                    startActivity(intent);
                } else if (itemID == R.id.nav_Settings) {
                    Intent intent = new Intent(ReportPage.this, SettingsPage.class);
                    startActivity(intent);
                }
                return true;
            }
        });
    }
}
