package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/**
 * Activity class for displaying running exercise video.
 */
public class RunningExercice extends AppCompatActivity {

    private WebView webView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_running_exercice);

        // Initialize WebView
        webView3 = findViewById(R.id.webView3);

        // Embed YouTube video in WebView
        String video = "<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/_kGESn8ArrU?si=ncSxiNaFbrJH9RLy\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>";
        webView3.loadData(video, "text/html","utf-8");

        // Enable JavaScript in WebView
        webView3.getSettings().setJavaScriptEnabled(true);

        // Set WebChromeClient for WebView
        webView3.setWebChromeClient(new WebChromeClient());
    }
}
