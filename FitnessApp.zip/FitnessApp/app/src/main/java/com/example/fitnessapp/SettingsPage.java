package com.example.fitnessapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

/**
 * Activity class for the settings page.
 */
public class SettingsPage extends AppCompatActivity {

    private Switch switchDarkMode;
    private Button btnResetData;
    private BottomNavigationView nav;
    private CardView TroubleShooting;
    private TextView StepNumberTxt, DistanceTravelledTxt, CaloriesBurnedTxt;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_page);

        // Initialize views
        switchDarkMode = findViewById(R.id.switchDarkMode);
        btnResetData = findViewById(R.id.btnResetData);
        nav = findViewById(R.id.nav);
        StepNumberTxt = findViewById(R.id.StepsNumberTxt);
        DistanceTravelledTxt = findViewById(R.id.DistanceTravelledTxt);
        CaloriesBurnedTxt = findViewById(R.id.CaloriesBurnedTxt);
        TroubleShooting = findViewById(R.id.TroubleShooting);

        // Button to navigate to troubleshooting card
        TroubleShooting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SettingsPage.this, TroubleShootingCard.class);
                startActivity(intent);
            }
        });

        // Button to reset data
        btnResetData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StepNumberTxt.setText("0");
                DistanceTravelledTxt.setText("Distance: 0.00 km");
                CaloriesBurnedTxt.setText("Calories Burned: 0.00");
            }
        });

        // Bottom navigation item selection
        nav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemID = item.getItemId();
                if (itemID == R.id.nav_menu) {
                    Intent intent = new Intent(SettingsPage.this, StepCounter.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("currentStep", StepNumberTxt.getText().toString());
                    intent.putExtra("currentDistance", DistanceTravelledTxt.getText().toString());
                    intent.putExtra("currentCalories", CaloriesBurnedTxt.getText().toString());
                    startActivity(intent);
                } else if (itemID == R.id.nav_report) {
                    Intent intent = new Intent(SettingsPage.this, ReportPage.class);
                    startActivity(intent);
                } else if (itemID == R.id.nav_Workout) {
                    Intent intent = new Intent(SettingsPage.this, WorkoutPage.class);
                    startActivity(intent);
                }
                return true;
            }
        });

        // Switch for dark mode
        switchDarkMode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    // Set dark mode
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    // Set light mode
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }
            }
        });
    }
}
