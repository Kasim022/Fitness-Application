package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/**
 * Activity class for displaying sit-ups exercise video.
 */
public class SitupsExercise extends AppCompatActivity {

    private WebView webView4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_situps_exercise);

        // Initialize WebView
        webView4 = findViewById(R.id.webView4);

        // Embed YouTube video in WebView
        String video = "<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/jDwoBqPH0jk?si=_63EpYzolE-FvBT8\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>";
        webView4.loadData(video, "text/html","utf-8");

        // Enable JavaScript in WebView
        webView4.getSettings().setJavaScriptEnabled(true);

        // Set WebChromeClient for WebView
        webView4.setWebChromeClient(new WebChromeClient());
    }
}
