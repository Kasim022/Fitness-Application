package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/**
 * Activity class for displaying skipping exercise video.
 */
public class SkippingExercise extends AppCompatActivity {

    private WebView webView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skipping_exercise);

        // Initialize WebView
        webView1 = findViewById(R.id.webView1);

        // Embed YouTube video in WebView
        String video = "<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/DTdaiqR9now?si=Bfr68mIqM3jkOe3F\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>";
        webView1.loadData(video, "text/html","utf-8");

        // Enable JavaScript in WebView
        webView1.getSettings().setJavaScriptEnabled(true);

        // Set WebChromeClient for WebView
        webView1.setWebChromeClient(new WebChromeClient());
    }
}
