package com.example.fitnessapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ReportFragment;
import androidx.fragment.app.Fragment;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class StepCounter extends AppCompatActivity implements SensorEventListener {

    private TextView BMIResult, DistanceTravelledTxt, CaloriesBurnedTxt, StepsNumberTxt, StepsNumberTargetTxt, AchivementNumber;
    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private SensorManager SensorManager = null;
    private Sensor StepSensor;
    private int totalstep = 0;
    private int previewTotalStep = 0;
    private Bundle extras;
    private CardView BMILayout, DistanceTravelledLayout, CaloriesBurnedLayout;
    private BottomNavigationView nav;
    private FrameLayout frameLayout;
    private BarChart barChart;
    private ImageView AchievmentsIcon;
    private int targetSteps;

    private static final double BMI_UNDERWEIGHT = 18.5;
    private static final double BMI_NORMAL = 25.0;
    private static final double BMI_OVERWEIGHT = 30.0;
    private static final double BMI_OBESE_1 = 35.0;
    private static final double BMI_OBESE_2 = 40.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step_counter);

        progressBar = findViewById(R.id.ProgressBar);
        StepsNumberTxt = findViewById(R.id.StepsNumberTxt);
        BMIResult = findViewById(R.id.BMIResult);
        DistanceTravelledTxt = findViewById(R.id.DistanceTravelledTxt);
        CaloriesBurnedTxt = findViewById(R.id.CaloriesBurnedTxt);
        AchievmentsIcon = findViewById(R.id.AchivementIcon);
        AchivementNumber = findViewById(R.id.AchivementNumber);
        StepsNumberTargetTxt = findViewById(R.id.StepsNumberTargetTxt);
        BMILayout = findViewById(R.id.BMILayout);
        DistanceTravelledLayout = findViewById(R.id.DistanceTravelledLayout);
        CaloriesBurnedLayout = findViewById(R.id.CaloriesBurnedLayout);
        frameLayout = findViewById(R.id.frameLayout);

        mAuth = FirebaseAuth.getInstance();

        SensorManager = (android.hardware.SensorManager) getSystemService(SENSOR_SERVICE); //access to Sensors
        StepSensor = SensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        extras = getIntent().getExtras();

        nav = findViewById(R.id.nav);


        //Navigation Bar linked to other activities
        nav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemID = item.getItemId(); {

                    if (itemID == R.id.nav_menu) {
                        Intent intent = new Intent(StepCounter.this, StepCounter.class);
                        intent.putExtra("CurrentStep", StepsNumberTxt.getText().toString());
                        startActivity(intent);

                    } else if (itemID == R.id.nav_report) {
                        Intent intent = new Intent(StepCounter.this, ReportPage.class);
                        intent.putExtra("currentStep", StepsNumberTxt.getText().toString());
                        startActivity(intent);

                    } else if (itemID == R.id.nav_Workout) {
                        Intent intent = new Intent(StepCounter.this, WorkoutPage.class);
                        startActivity(intent);

                    } else if (itemID == R.id.nav_Settings) {
                        Intent intent = new Intent(StepCounter.this, SettingsPage.class);
                        startActivity(intent);
                    }
                }
                return true;
            }
        });

        BMILayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StepCounter.this, BMICard.class);
                intent.putExtra("BMIResult", Double.parseDouble(BMIResult.getText().toString().split(" ")[2])); // Pass the BMI value to the BMICard activity
                Toast.makeText(StepCounter.this, "BMI", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });

        DistanceTravelledLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StepCounter.this, DistanceTravelledCard.class);
                Toast.makeText(StepCounter.this, "Distance Travelled", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });

        CaloriesBurnedLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StepCounter.this, CaloriesBurnedCard.class);
                Toast.makeText(StepCounter.this, "Calories Burned", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });

    }

    protected void onResume() {
        super.onResume();

        if (StepSensor == null) {
            Toast.makeText(this, "This Device has no Sensor", Toast.LENGTH_SHORT).show();
        } else {
            SensorManager.registerListener(this, StepSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }

        if (extras != null && extras.containsKey("BMIResult")) {
            String bmiResult = extras.getString("BMIResult", "0.0");

            // Display the BMI result in the TextView
            BMIResult.setText("BMI Result: " + bmiResult);

            double bmiValue = Double.parseDouble(bmiResult);
            calculateAndSetTargetSteps(bmiValue);

            // Update the user's document in Firestore
            FirebaseUser user = mAuth.getCurrentUser();
            if (user != null) {
                String uid = user.getUid();
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                DocumentReference userRef = db.collection("users").document(uid);

                Map<String, Object> userData = new HashMap<>();
                userData.put("bmi", bmiValue);

                userRef.set(userData, SetOptions.merge()).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(StepCounter.this, "Failed", Toast.LENGTH_SHORT).show();
                            }
                        });
            }

        }
    }

    protected void onPause() {
        super.onPause();
        SensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
            // Calculating Step Counter
        if (sensorEvent.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            totalstep = (int) sensorEvent.values[0];
            int currentStep = totalstep - previewTotalStep;
            StepsNumberTxt.setText(String.valueOf(currentStep));
            progressBar.setProgress(currentStep);

            // Check if the user has reached the target steps
            if (currentStep >= targetSteps) {
                int achievementNumber = Integer.parseInt(AchivementNumber.getText().toString());
                achievementNumber++;
                AchivementNumber.setText(String.valueOf(achievementNumber));

                showNotification("Congratulations!", "You have reached your target steps!");
            }
            //Calculating Distance Travelled
            String stepsString = StepsNumberTxt.getText().toString();
            int steps = Integer.parseInt(stepsString);
            double stepLengthInMeters = 0.7;
            double distanceInKm = steps * stepLengthInMeters / 1000;
            DistanceTravelledTxt.setText(String.format(Locale.getDefault(),"Distance: %.2f km", distanceInKm));

            //Calculating Calories Burned
            double caloriesPerKm = 0.05;
            double distanceInKmm = steps * stepLengthInMeters / 1000;
            double caloriesBurned = (double) (distanceInKmm * caloriesPerKm);
            CaloriesBurnedTxt.setText(String.format("Calories Burned: %.2f", caloriesBurned));
        }
    }

    private void showNotification(String title, String message ) {

        Intent intent = new Intent(this, StepCounter.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity( this, 0, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_ONE_SHOT);

        String channelID = "Fitness_app_Notification";
        NotificationCompat.Builder builder = new NotificationCompat.Builder( this, channelID)
                .setContentTitle("Fitness App")
                .setContentText("Congratulations! You have reached your target step")
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setAutoCancel(true);

        NotificationManager  notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // For Android 8.0 and above, we need to create a notification channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence channelName = "Fitness App Notifications";
            String channelDescription = "Notifications for Fitness App";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(channelID, channelName, importance);
            channel.setDescription(channelDescription);
            notificationManager.createNotificationChannel(channel);
        }

        notificationManager.notify(0, builder.build());

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
    // Method to calculate and set target steps based on BMI
    private void calculateAndSetTargetSteps(double bmiValue) {
        int targetSteps;
        if (bmiValue < BMI_NORMAL) {
            targetSteps = 7000;
        } else if (bmiValue < BMI_OVERWEIGHT) {
            targetSteps = 10000;
        } else if (bmiValue < BMI_OBESE_1) {
            targetSteps = 11000;
        } else if (bmiValue < BMI_OBESE_2) {
            targetSteps = 12000;
        } else {
            targetSteps = 13000;
        }
        StepsNumberTargetTxt.setText("Target Steps: " + targetSteps);
    }


}



