package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/**
 * Activity class for displaying swimming exercise video.
 */
public class SwimmingExercise extends AppCompatActivity {

    private WebView webView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_swimming_exercise);

        // Initialize WebView
        webView2 = findViewById(R.id.webView2);

        // Embed YouTube video in WebView
        String video = "<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/AQy_c30lNjI?si=LQDP4IU6cCnE28mX\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>";
        webView2.loadData(video, "text/html", "utf-8");

        // Enable JavaScript in WebView
        webView2.getSettings().setJavaScriptEnabled(true);

        // Set WebChromeClient for WebView
        webView2.setWebChromeClient(new WebChromeClient());
    }
}
