package com.example.fitnessapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

/**
 * Activity class for the Workout Page.
 */
public class WorkoutPage extends AppCompatActivity {

    // CardViews for different workout options
    private CardView SkippingCardLayout, SwimmingCardLayout, RunningCardLayout, SitupsCardLayout;

    // Bottom Navigation View and TextView for AI Chatbot
    private BottomNavigationView nav;
    private TextView AI_Bot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_page);

        // Initialize views
        SkippingCardLayout = findViewById(R.id.SkippingCardLayout);
        SwimmingCardLayout = findViewById(R.id.SwimmingCardLayout);
        RunningCardLayout = findViewById(R.id.RunningCardLayout);
        SitupsCardLayout = findViewById(R.id.SitupsCardLayout);
        AI_Bot = findViewById(R.id.AI_Bot);
        nav = findViewById(R.id.nav);

        // Navigation Bar linked to other activities
        nav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemID = item.getItemId();
                {
                    if (itemID == R.id.nav_menu) {
                        // Navigate to Step Counter activity
                        Intent intent = new Intent(WorkoutPage.this, StepCounter.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    } else if (itemID == R.id.nav_report) {
                        // Navigate to Report Page activity
                        Intent intent = new Intent(WorkoutPage.this, ReportPage.class);
                        startActivity(intent);
                    } else if (itemID == R.id.nav_Workout) {
                        // Already in Workout Page
                    } else if (itemID == R.id.nav_Settings) {
                        // Navigate to Settings Page activity
                        Intent intent = new Intent(WorkoutPage.this, SettingsPage.class);
                        startActivity(intent);
                    }
                }
                return true;
            }
        });

        // Click listener for AI Bot TextView
        AI_Bot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to AI Chatbot activity
                Intent intent = new Intent(WorkoutPage.this, AI_Chatbot.class);
                startActivity(intent);
            }
        });

        // Click listeners for different workout options
        SkippingCardLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to Skipping Exercise activity
                Intent intent = new Intent(WorkoutPage.this, SkippingExercise.class);
                startActivity(intent);
            }
        });

        SwimmingCardLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to Swimming Exercise activity
                Intent intent = new Intent(WorkoutPage.this, SwimmingExercise.class);
                startActivity(intent);
            }
        });

        RunningCardLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to Running Exercise activity
                Intent intent = new Intent(WorkoutPage.this, RunningExercice.class);
                startActivity(intent);
            }
        });

        SitupsCardLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to Situps Exercise activity
                Intent intent = new Intent(WorkoutPage.this, SitupsExercise.class);
                startActivity(intent);
            }
        });
    }
}
