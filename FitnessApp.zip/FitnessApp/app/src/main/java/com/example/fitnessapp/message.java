package com.example.fitnessapp;

/**
 * Class representing a message in the chat.
 */
public class message {
    // Constants for identifying sender
    public static String SENT_BY_ME = "me";
    public static String SENT_BY_BOT = "bot";

    // Message content
    String message;
    // Sender of the message
    String sentBy;

    /**
     * Constructor for creating a message.
     * @param message The content of the message.
     * @param sentBy Identifier for the sender of the message.
     */
    public message(String message, String sentBy) {
        this.message = message;
        this.sentBy = sentBy;
    }

    /**
     * Getter for retrieving the message content.
     * @return The message content.
     */
    public String getMessage() {
        return message;
    }

    /**
     * Setter for setting the message content.
     * @param message The message content to set.
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Getter for retrieving the sender of the message.
     * @return The identifier for the sender of the message.
     */
    public String getSentBy() {
        return sentBy;
    }

    /**
     * Setter for setting the sender of the message.
     * @param sentBy The identifier for the sender of the message.
     */
    public void setSentBy(String sentBy) {
        this.sentBy = sentBy;
    }
}
