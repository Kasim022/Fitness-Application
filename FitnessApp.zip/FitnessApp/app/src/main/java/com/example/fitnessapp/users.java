package com.example.fitnessapp;

/**
 * Represents a user in the fitness application.
 */
public class users {
    // User attributes
    private String FirstName;
    private String LastName;
    private String Email;
    private String Password;
    private String BMI;

    /**
     * Gets the first name of the user.
     * @return The first name of the user.
     */
    public String getFirstName() {
        return FirstName;
    }

    /**
     * Sets the first name of the user.
     * @param firstName The first name of the user to set.
     */
    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    /**
     * Gets the last name of the user.
     * @return The last name of the user.
     */
    public String getLastName() {
        return LastName;
    }

    /**
     * Sets the last name of the user.
     * @param lastName The last name of the user to set.
     */
    public void setLastName(String lastName) {
        LastName = lastName;
    }

    /**
     * Gets the email of the user.
     * @return The email of the user.
     */
    public String getEmail() {
        return Email;
    }

    /**
     * Sets the email of the user.
     * @param email The email of the user to set.
     */
    public void setEmail(String email) {
        Email = email;
    }

    /**
     * Gets the password of the user.
     * @return The password of the user.
     */
    public String getPassword() {
        return Password;
    }

    /**
     * Sets the password of the user.
     * @param password The password of the user to set.
     */
    public void setPassword(String password) {
        Password = password;
    }

    /**
     * Gets the BMI (Body Mass Index) of the user.
     * @return The BMI of the user.
     */
    public String getBMI() {
        return BMI;
    }

    /**
     * Sets the BMI (Body Mass Index) of the user.
     * @param BMI The BMI of the user to set.
     */
    public void setBMI(String BMI) {
        this.BMI = BMI;
    }
}
